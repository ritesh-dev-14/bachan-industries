export const products = [
  {
    id: 'fiber-laser', category: 'Laser systems', name: 'CNC Fiber Laser Cutting Machine',
    desc: 'High-speed, accurate metal cutting built for demanding production environments.',
    image: 'https://images.unsplash.com/photo-1567789884554-0b844b597180?auto=format&fit=crop&w=1200&q=85',
    tag: 'Precision cutting'
  },
  {
    id: 'plasma', category: 'Plasma systems', name: 'CNC Plasma Cutting Machine',
    desc: 'Dependable thermal cutting for robust plate processing and fabrication work.',
    image: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=1200&q=85',
    tag: 'Heavy-duty'
  },
  {
    id: 'router', category: 'Router systems', name: 'CNC Wood Router',
    desc: 'Repeatable routing performance for detailed designs and efficient workflows.',
    image: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=85',
    tag: 'Versatile'
  },
  {
    id: 'welding', category: 'Laser solutions', name: 'Handheld Laser Welding',
    desc: 'A modern welding solution designed for clean joins and flexible operation.',
    image: 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&w=1200&q=85',
    tag: 'Next generation'
  },
  {
    id: 'marking', category: 'Marking systems', name: 'Fiber Laser Marking Machine',
    desc: 'Clear, consistent marking for product identification and traceability.',
    image: 'https://images.unsplash.com/photo-1581092334651-ddf26d9a09d0?auto=format&fit=crop&w=1200&q=85',
    tag: 'Fine detail'
  },
  {
    id: 'service', category: 'Parts & service', name: 'Laser Heads, Spares & Retrofit',
    desc: 'Practical support, replacement parts and retrofit options that extend machine life.',
    image: 'https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=1200&q=85',
    tag: 'Lifecycle support'
  }
]
export const capabilities = ['CNC Fiber Laser', 'CNC Plasma Cutting', 'CNC Wood Router', 'Laser Welding & Marking', 'Spare Parts & Retrofit', 'Installation & Maintenance']